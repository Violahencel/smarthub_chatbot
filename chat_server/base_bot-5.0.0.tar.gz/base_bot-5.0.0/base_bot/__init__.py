import queue
import asyncio
import re
import uuid
import socketio
import os
import time
import json
import threading
import random
import sys
import signal
import datetime
from dotenv import load_dotenv

from base_bot.configurable_base_bot import ConfigurableApp

from typing import List, Dict, Any, Optional

def get_current_utc_time():
    return datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

class Task:
    def __init__(self, id, name, status, result: Optional[any] = None):
        self.id = id
        self.name = name
        self.status = status
        self.startTime = get_current_utc_time()
        self.endTime = None
        self.result = result

class BotState:
    def __init__(self):
        self.tasks: List[Task] = []
        # # self.channel_states: Dict[str, bool] = {}
        # self.bot_state: Dict[str, Task] = {}

    def to_dict(self):
        return {
            "tasks": [task.__dict__ for task in self.tasks]
        }

class EventEmitter:
    def __init__(self, options=None):
        super().__init__(options)
        self._events = {}
        
    def on(self, event, listener):
        if event not in self._events:
            self._events[event] = []
        self._events[event].append(listener)
        
    def emit(self, event, *args, **kwargs):
        if event in self._events:
            for listener in self._events[event]:
                listener(*args, **kwargs)
                
class BaseBot(EventEmitter, ConfigurableApp):
    def __init__(self, options=None):
        
        super().__init__(options)
        
        
        
        # Load environment variables
        load_dotenv()
        
        print('base bot intialization')
        # Bot configuration with defaults and overrides
        options = options or {}
        self.config.update({
            "bot_id": options.get("bot_id", os.getenv("BOT_ID", "base-bot")),
            "window_hwnd": options.get("window_hwnd", 0),
            "commands": options.get("commands", {}),
            "bot_name": options.get("bot_name", os.getenv("BOT_NAME", "Base Bot")),
            "bot_type": options.get("bot_type", os.getenv("BOT_TYPE", "base")),
            "server_url": options.get("server_url", os.getenv("SERVER_URL", "http://localhost:3000")),
            "default_channel": options.get("default_channel", os.getenv("DEFAULT_CHANNEL", "general")),
            "max_reconnect_attempts": int(options.get("max_reconnect_attempts", os.getenv("MAX_RECONNECT_ATTEMPTS", "5"))),
            "disable_console_input": options.get("disable_console_input", False)
        })
        # self.config.update(options)
        # Current state
        bot_state = BotState()
        self.state = {
            "current_channel_id": None,
            "is_connected": False,
            "connection_attempts": 0,
            "bot_state": bot_state,
            "channel_states": {}  # Track active state of channels
        }
        
        # Input handling
        self.input_thread = None
        self.running = False
        
        
        # For thread management
        self._running = False
        self._thread = None
        self._completed = threading.Event()
        self._message_queue = queue.Queue()
        self._exit_flag = threading.Event()  # Flag to signal exit for all threads
        self._input_thread = None  # Thread for handling console input
        
        # Set up signal handler for graceful exit
        self._original_sigint_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, self._signal_handler)
        
        #Thread management END
        
        # Initialize the bot
        self.init()
        
        self.pending_futures = {}  # Store pending futures
        
    def init(self):
        """Initialize the bot"""
        self.initSocket()
        self.setupSocketHandlers()
        
        # Display initial prompt
        self.display_prompt()
        
        # Start the bot (connect and setup console)
        # self.start()
        
        # Emit initialized event
        # self.emit("initialized")
        
    def initSocket(self):
        """Initialize the Socket.IO client"""
        self.socket = socketio.Client(
            reconnection=True,
            reconnection_attempts=self.config["max_reconnect_attempts"],
            reconnection_delay=1,
            reconnection_delay_max=5,
            request_timeout=20
        )
        # Store the server URL and path
        self.server_url = self.config["server_url"]
        self.server_path = '/api/socket'
    
    def cancel_all_active_tasks(self):
        bot_state = self.state["bot_state"]
        for task in bot_state.tasks:
            if task.status == "in_progress":
                self.task_ended(task.id, "cancelled")
    
    async def can_bot_receive_new_task(self, target_bot_id):
        result = await self.enquire_bot_state(target_bot_id)
        data = result.get("data", None)
        if not data:
            return False
        tasks = data.get("tasks", [])
        return not any(task.get("status") == "in_progress" for task in tasks)
    

    async def enquire_bot_state(self, target_bot_id):
        msg_id = str(uuid.uuid4())
        request = {
            "targetBotId": target_bot_id,
            "msg_id": msg_id
        }
        
        # Create a future and store it
        try:
            # Use the main event loop
            loop = asyncio.get_running_loop()
            future = loop.create_future()
            self.pending_futures[msg_id] = future
            
            # Emit the request
            self.socket.emit("enquire_bot_state", request)
            
            # Add timeout to prevent hanging
            try:
                return await asyncio.wait_for(future, timeout=2.0)
            except asyncio.TimeoutError:
                self.print_message(f"Timeout waiting for response to enquire_bot_state with msg_id: {msg_id}")
                if msg_id in self.pending_futures:
                    del self.pending_futures[msg_id]
                raise
        except Exception as e:
            self.print_message(f"Error in enquire_bot_state: {str(e)}")
            if msg_id in self.pending_futures:
                del self.pending_futures[msg_id]
            raise

    def on_private_message(self, message):
        print('Unhandled private message base:', message)
        
    def setupSocketHandlers(self):
        """Set up Socket.IO event handlers"""
        # Connection events
        @self.socket.event
        def connect():
            self.state["is_connected"] = True
            self.state["connection_attempts"] = 0
            self.print_message("Connected to server")
            
            # Register the bot
            self.socket.emit("register", {
                "botId": self.config["bot_id"],
                "name": self.config["bot_name"],
                "type": self.config["bot_type"],
                "window_hwnd": self.config["window_hwnd"],
                "commands": self.config["commands"],
                "bot_state": self.state["bot_state"].to_dict()
            })
            
            self.print_message(f'Registered as {self.config["bot_name"]} ({self.config["bot_id"]}) ({self.config["window_hwnd"]})')
            self.display_prompt()
            
            # Emit connected event
            self.emit("connected")
            
        @self.socket.event
        def disconnect():
            self.state["is_connected"] = False
            self.print_message("Disconnected from server")
            self.display_prompt()
            
            # Emit disconnected event
            self.emit("disconnected")
            
        @self.socket.event
        def connect_error(error):
            self.state["connection_attempts"] += 1
            self.print_message(f'Connection error: {str(error)}')
            
            if self.state["connection_attempts"] < self.config["max_reconnect_attempts"]:
                self.print_message(f'Reconnection attempt {self.state["connection_attempts"]}/{self.config["max_reconnect_attempts"]}...')
            else:
                self.print_message(f'Failed to connect after {self.config["max_reconnect_attempts"]} attempts.')
                self.print_message("Use /reconnect to try again or check server status.")
            
            self.display_prompt()
            
            # Emit error event
            self.emit("error", error)
            
        # Message events
        @self.socket.on("control_command")
        def on_control_command(message):
            self.print_message(f"Control command: {message}")
            if message.get('targetId') == self.config["bot_id"]:
                self.emit("control_command", message)
                if message.get('command') == 'cancel':
                    self.cancel_all_active_tasks()
       
        @self.socket.on("private-message")
        def on_private_message_from_server(message):
            self.print_message(f"Private message from server received @ base: {message}")
            if message.get('msg_type') == "response" and message.get('msg_id') in self.pending_futures:
                self.print_message(f"Resolving future for msg_id: {message.get('msg_id')}")
                future = self.pending_futures.pop(message.get('msg_id'))
                future.set_result(message)
            else:
                self.print_message(f"NOT A RESPONSE, NO future for this message.")
                self.on_private_message(message)
                
                
        @self.socket.on("new_message")
        def on_new_message(message):
            # Don't show our own messages again
            if message.get("senderId") != self.config["bot_id"]:
                self.print_message(f"{message.get('senderName')}: {message.get('content')}")
                
                if self.should_respond_to(message):
                    # Create a delay to seem more human-like
                    delay = 0.5; #1 + random.random() * 2  # 1-3 seconds
                    
                    def delayed_response():
                        time.sleep(delay)
                        
                        if not self.state["is_connected"]:
                            self.print_message("Cannot respond to message: Not connected to server")
                            self.display_prompt()
                            return
                        
                        # Check if the channel is active before responding
                        if self.state["channel_states"].get(message.get("channelId")) is False:
                            self.print_message(f"Cannot respond to message: Channel {message.get('channelId')} is inactive")
                            self.display_prompt()
                            return
                        
                        # try:
                            
                        json_content = self.extract_json_block(message.get("content"))
                        if json_content:
                            message["json"] = json_content
                            
                        self.emit('new_message', message)
                        # self.display_prompt()
                            
                            # # Create a new event loop for this thread
                            # loop = asyncio.new_event_loop()
                            # asyncio.set_event_loop(loop)
                            
                            # Run the async generate_response method
                        #     try:
                        #         response = loop.run_until_complete(self.generate_response(message))
                        #     except Exception as e:
                        #         retry_text = ""
                        #         if json_content:
                        #             jc = json.dumps(json_content)
                        #             retry_text = f" [json]{jc}[/json] [Retry]"
                                    
                        #         self.print_message(f"Error x01: {str(e)}")
                        #         response = f"Error x01: {str(e)} {retry_text}"
                        #         self.cancel_all_active_tasks()
                        #     finally:
                        #         # Clean up
                        #         loop.close()    
                            
                        #     # Send the response
                        #     self.socket.emit("message", {
                        #         "channelId": message.get("channelId"),
                        #         "content": response
                        #     })
                            
                        #     self.print_message(f"You responded to {message.get('senderName')}: {response}")
                        # except Exception as e:
                        #     self.print_message(f"Error generating response x02: {str(e)}")
                        #     self.socket.emit("message", {
                        #         "channelId": message.get("channelId"),
                        #         "content": f"Error x02: {str(e)}"
                        #     })
                        # finally:
                        #     self.cancel_all_active_tasks()
                            # self.display_prompt()
                    
                    delayed_response()
            
            self.display_prompt()
            
            # Emit message event
            self.emit("message", message)
            
        # Channel events
        @self.socket.on("channel_status")
        def on_channel_status(data):
            self.print_message(f"Channel status: {data.get('channelId')} ({'active' if data.get('active') else 'inactive'})")
            self.print_message(f'Participants: {len(data.get("participants", []))}')
            
            # Update channel state
            self.state["channel_states"][data.get("channelId")] = data.get("active")
            
            self.display_prompt()
            
            # Emit channel status event
            self.emit("channelStatus", data)
            
        @self.socket.on("participant_joined")
        def on_participant_joined(data):
            self.print_message(f"Participant joined: {data.get('name')} ({data.get('participantId')})")
            self.display_prompt()
            
            # Emit participant joined event
            self.emit("participantJoined", data)
            
        @self.socket.on("participant_left")
        def on_participant_left(data):
            self.print_message(f"Participant left: {data.get('name') or data.get('participantId')}")
            self.display_prompt()
            
            # Emit participant left event
            self.emit("participantLeft", data)
            
        @self.socket.on("channel_started")
        def on_channel_started(data):
            self.print_message(f"Channel started: {data.get('channelId')}")
            
            # Update channel state to active
            self.state["channel_states"][data.get("channelId")] = True
            
            self.display_prompt()
            
            # Emit channel started event
            self.emit("channelStarted", data)
            
        @self.socket.on("channel_stopped")
        def on_channel_stopped(data):
            self.print_message(f"Channel stopped: {data.get('channelId')}")
            
            # Update channel state to inactive
            self.state["channel_states"][data.get("channelId")] = False
            
            self.display_prompt()
            
            # Emit channel stopped event
            self.emit("channelStopped", data)
            
        @self.socket.on("bot_registered")
        def on_bot_registered(data):
            self.print_message(f"Bot registered: {data.get('name')} ({data.get('botId')})")
            self.display_prompt()
            
            # Emit bot registered event
            self.emit("botRegistered", data)
            
            if self.options.get('autojoin_channel', None) is not None:
                print('----------------autojoining channel', self.options.get('autojoin_channel', None))
                self.process_command(f"/join {self.options.get('autojoin_channel', None)}")

    def new_task_started(self, task_id, task_name):
        bot_state = self.state["bot_state"]
        task = Task(task_id, task_name, "in_progress", None)
        bot_state.tasks.append(task)
        self.state["bot_state"] = bot_state
        
        self.socket.emit("bot_state_updated", {
            "botId": self.config["bot_id"],
            "botState": bot_state.to_dict()
        })
    
    def task_ended(self, task_id, result: Optional[any] = None):
        bot_state = self.state["bot_state"]
        task = next((t for t in bot_state.tasks if t.id == task_id), None)
        if task:
            task.endTime = get_current_utc_time()
            task.result = result
            task.status = "completed"
            
        # Keep no more than 7 tasks in the task list, remove older ones
        if len(bot_state.tasks) > 7:
            bot_state.tasks = bot_state.tasks[-7:]
            
        self.socket.emit("bot_state_updated", {
            "botId": self.config["bot_id"],
            "botState": bot_state.to_dict()
        })
        
        self.state["bot_state"] = bot_state

    def get_bot_state(self):
        bot_state = self.state["bot_state"]
        return bot_state

    def extract_json_block(self, content):
        """Extract JSON block from content"""
        try:
            regex = re.compile(r'\[json\](.*?)\[\/json\]', re.DOTALL)
            match = regex.search(content)
            jsonMatch = match.group(1) if match else None
            if jsonMatch:
                return json.loads(jsonMatch)
        except Exception as error:
            self.print_message(f"Error parsing JSON: {error}")
            return None
    

    def extract_json_data(self, message):
        jsonData = message.get("jsonData", None)
        if jsonData:
            json_key = list(jsonData.keys())[0]
            return jsonData[json_key]
        return None  
    
    # Thread management START
    
    def _signal_handler(self, sig, frame):
        """Internal signal handler for Ctrl+C"""
        print("\nCtrl+C detected! Shutting down gracefully...")
        self.stop()
        sys.exit(0)
    
    def console_input_handler(self):
        """Thread function to handle user input from console"""
        try:
            while self._running and not self._exit_flag.is_set():
                try:
                    # Use input() in a separate thread to get commands
                    cmd = input(f"\n[{self.config['bot_name']}] > ").strip()
                    if self._running:  # Check again in case we were stopped while waiting for input
                        self._message_queue.put(cmd)
                except EOFError:
                    # Handle EOF (Ctrl+D)
                    self._exit_flag.set()
                    break
                except KeyboardInterrupt:
                    # Handle Ctrl+C
                    print(f"\n{self.config['bot_name']} interrupted by user")
                    self._exit_flag.set()
                    break
                except Exception as e:
                    print(f"Input error: {e}")
        except Exception as e:
            print(f"Console input handler error: {e}")
    
    def runUntilStopped(self):
        print(f'{self.config["bot_name"]} started running')
        try:
            self._running = True
            
            # Start the console input thread if not disabled
            if not self.config["disable_console_input"]:
                self._input_thread = threading.Thread(target=self.console_input_handler)
                self._input_thread.daemon = True
                self._input_thread.start()
                print(f"Console input enabled for {self.config['bot_name']}")
            
            # Use an event to block until signaled to exit
            while self._running and not self._exit_flag.is_set():
                try:
                    # Check for messages in the queue with a timeout
                    try:
                        cmd = self._message_queue.get(timeout=0.5)
                        self.process_command(cmd)
                    except queue.Empty:
                        # No message, just continue waiting
                        pass
                except KeyboardInterrupt:
                    print(f'\n{self.config["bot_name"]} process interrupted')
                    break
        except Exception as e:
            print(f'Error in {self.config["bot_name"]}: {e}')
        finally:
            # Stop the input thread if it's running
            if self._input_thread and self._input_thread.is_alive():
                # Can't really stop the input thread directly because it's blocked on input()
                # But we've set the flags so it will exit after the next input
                pass
                
            print(f'{self.config["bot_name"]} finished running')
            self._running = False
            self._completed.set()  # Signal that parent has completed
        
    def start(self):
        try:
            # Start the socket.io connection
            if not self.state["is_connected"]:
                try:
                    self.socket.connect(
                        url=self.server_url,
                        socketio_path=self.server_path
                    )
                except Exception as e:
                    print(f"Socket connection error: {e}")
                    self.emit("error", e)
                    
            # Reset flags before starting
            if self._exit_flag.is_set():
                self._exit_flag.clear()
            self._completed.clear()
            
            # Start the main thread if not already running
            if not self._running:
                self._running = True
                if self._thread and self._thread.is_alive():
                    print("Thread already running, not starting a new one")
                else:
                    # Reset the exit flag before starting
                    self._exit_flag.clear()
                    self._thread = threading.Thread(target=self.runUntilStopped)
                    self._thread.daemon = True  # Make threads daemon to auto-exit on main thread exit
                    self._thread.start()
                    print(f"Started thread for {self.config['bot_name']}")
            
            # Return self for method chaining
            return self
            
        except Exception as e:
            print(f"Error starting bot: {e}")
            self.emit("error", e)
            return self
    
    def add_command(self, command):
        """Add a command to the message queue for processing"""
        if self._running:
            self._message_queue.put(command)
            return True
        return False
    
    def stop(self):
        """Stop all threads gracefully"""
        print(f"Stopping {self.config['bot_name']}...")
        
        self.cancel_all_active_tasks()
        time.sleep(0.5)        
        
        self._exit_flag.set()
        self._running = False
        
        # Disconnect socket if connected
        if self.state["is_connected"]:
            print(f"Disconnecting {self.config['bot_name']} from server...")
            if self.state["current_channel_id"]:
                self.socket.emit("leave_channel", self.state["current_channel_id"])
            self.socket.disconnect()
        
        self._completed.set()
        
        time.sleep(0.5)  # Small delay to allow threads to respond
        # Restore original signal handler
        signal.signal(signal.SIGINT, self._original_sigint_handler)
        
        if self._thread and self._thread.is_alive():
            print(f"Waiting for {self.config['bot_name']} thread to complete...")
            self._thread.join(timeout=2.0)  # Wait up to 2 seconds for thread to end
        
        # We don't join the input thread because it might be blocked on input()
            
        print(f"{self.config['bot_name']} stopped")
    
    def join(self, timeout=None):
        """Wait for this parent to complete its execution"""
        try:
            if self._thread and self._thread.is_alive():
                self._thread.join(timeout)
            
            # if you need child also to have its own thread aside the parent, uncomment below 
            # if self._child_thread and self._child_thread.is_alive():
            #     self._child_thread.join(timeout)
            
        except KeyboardInterrupt:
            print("\nJoin interrupted. Stopping threads...")
            self.stop()
    
    def cleanup(self):
        """Clean up resources and restore original signal handlers"""
        self.stop()
    
    
    # Thread management END





    # def console_input_loop(self):
    #     """
    #     Console input loop to process user commands
    #     This uses a non-blocking approach to handle input
    #     """
    #     try:
    #         # On Windows, we need to use a simpler approach since select doesn't work with stdin
    #         if sys.platform.startswith('win'):
    #             self._win_console_loop()
    #         else:
    #             self._unix_console_loop()
    #     except KeyboardInterrupt:
    #         self.cleanup_and_exit()
    
    def send_message(self, message):
        self.socket.emit("message", {
            "channelId": self.state["current_channel_id"],
            "content": message
        })
   
    def cleanup_and_exit(self):
        """Clean up resources and exit gracefully"""
        if self.state["current_channel_id"] and self.state["is_connected"]:
            self.socket.emit("leave_channel", self.state["current_channel_id"])
        if self.state["is_connected"]:
            self.socket.disconnect()
        self.running = False
        self.print_message("Exiting bot")
        sys.exit(0)
    
    
    def process_command(self, input_text):
        """
        Process user commands
        
        Args:
            input_text (str): User input
        """
        trimmed_input = input_text.strip()
        
        # Check if it's a command (starts with /)
        if trimmed_input.startswith('/'):
            command_parts = trimmed_input[1:].split(' ')
            command = command_parts[0].lower()
            args = command_parts[1:] if len(command_parts) > 1 else []
            
            if command == 'join':
                join_channel_id = args[0] if args else self.config["default_channel"]
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot join channel.")
                    return
                self.socket.emit("join_channel", join_channel_id)
                self.state["current_channel_id"] = join_channel_id
                
                # When joining a channel, request its status to update our state
                def on_channel_details(data):
                    if data and isinstance(data.get("active"), bool):
                        self.state["channel_states"][join_channel_id] = data.get("active")
                        self.print_message(f"Channel {join_channel_id} is {'active' if data.get('active') else 'inactive'}")
                
                self.socket.emit("get_channel_details", join_channel_id, callback=on_channel_details)
                
                self.print_message(f"Joining channel: {join_channel_id}")
                
            elif command == 'leave':
                if not self.state["current_channel_id"]:
                    self.print_message("Error: Not in a channel")
                    return
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot leave channel.")
                    return
                self.socket.emit("leave_channel", self.state["current_channel_id"])
                self.print_message(f'Leaving channel: {self.state["current_channel_id"]}')
                self.state["current_channel_id"] = None
                
            elif command == 'start':
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot start channel.")
                    return
                start_channel_id = args[0] if args else self.state["current_channel_id"] or self.config["default_channel"]
                if not start_channel_id:
                    self.print_message("Error: No channel specified and not in a channel")
                    return
                self.socket.emit("start_channel", start_channel_id)
                self.state["current_channel_id"] = start_channel_id
                
                # When starting a channel, set its state to active
                self.state["channel_states"][start_channel_id] = True
                
                self.print_message(f"Starting channel: {start_channel_id}")
                
            elif command == 'stop':
                if not self.state["current_channel_id"]:
                    self.print_message("Error: Not in a channel")
                    return
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot stop channel.")
                    return
                self.socket.emit("stop_channel", self.state["current_channel_id"])
                
                # When stopping a channel, set its state to inactive
                self.state["channel_states"][self.state["current_channel_id"]] = False
                
                self.print_message(f'Stopping channel: {self.state["current_channel_id"]}')
                
            elif command == 'channel':
                new_channel_id = args[0] if args else None
                if not new_channel_id:
                    self.print_message(f'Current channel: {self.state["current_channel_id"] or "None"}')
                    if self.state["current_channel_id"]:
                        is_active = self.is_channel_active(self.state["current_channel_id"])
                        self.print_message(f"Channel status: {'Active' if is_active else 'Inactive'}")
                    return
                
                self.state["current_channel_id"] = new_channel_id
                
                # When switching channels, check its status if connected
                if self.state["is_connected"]:
                    def on_channel_details(data):
                        if data and isinstance(data.get("active"), bool):
                            self.state["channel_states"][new_channel_id] = data.get("active")
                            self.print_message(f"Channel {new_channel_id} is {'active' if data.get('active') else 'inactive'}")
                    
                    self.socket.emit("get_channel_details", new_channel_id, callback=on_channel_details)
                
                self.print_message(f"Switched to channel: {new_channel_id}")
                
            elif command == 'reconnect':
                if self.state["is_connected"]:
                    self.print_message("Already connected to server.")
                    return
                self.print_message("Attempting to reconnect to server...")
                try:
                    self.socket.connect(
                        url=self.server_url,
                        socketio_path=self.server_path
                    )
                except Exception as e:
                    self.print_message(f"Reconnection error: {str(e)}")
                
            elif command == 'info':
                if not self.state["current_channel_id"]:
                    self.print_message("Error: Not in a channel")
                    return
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot get channel info.")
                    return
                
                def on_channel_details(data):
                    self.print_message(f"Channel: {data.get('channelId')}")
                    self.print_message(f"Status: {'Active' if data.get('active') else 'Inactive'}")
                    
                    # Update our local state with the server's state
                    self.state["channel_states"][data.get("channelId")] = data.get("active")
                    
                    self.print_message(f'Participants: {len(data.get("participants", []))}')
                    self.print_message(f"Message count: {data.get('messageCount')}")
                
                self.socket.emit("get_channel_details", self.state["current_channel_id"], callback=on_channel_details)
                
            elif command == 'messages':
                if not self.state["current_channel_id"]:
                    self.print_message("Error: Not in a channel")
                    return
                if not self.state["is_connected"]:
                    self.print_message("Not connected to server. Cannot get messages.")
                    return
                
                def on_channel_messages(data):
                    self.print_message(f"Channel: {data.get('channelId')}")
                    messages = data.get('messages', [])
                    self.print_message(f"Message count: {len(messages)}")
                    if messages:
                        self.print_message("Recent messages:")
                        # Show last 5 messages
                        recent_messages = messages[-5:] if len(messages) > 5 else messages
                        for msg in recent_messages:
                            timestamp = datetime.datetime.fromtimestamp(msg.get('timestamp') / 1000)
                            time_str = timestamp.strftime("%H:%M:%S")
                            self.print_message(f'[{time_str}] {msg.get("senderName")}: {msg.get("content")}')
                
                self.socket.emit("get_channel_messages", self.state["current_channel_id"], callback=on_channel_messages)
                
            elif command == 'help':
                self.show_help()
                
            elif command == 'exit':
                if self.state["current_channel_id"] and self.state["is_connected"]:
                    self.socket.emit("leave_channel", self.state["current_channel_id"])
                self.socket.disconnect()
                self.running = False
                self.print_message("Exiting bot")
                sys.exit(0)
                
            else:
                # Check if the derived class has a custom command handler
                if not self.handle_custom_command(command, args):
                    self.print_message(f"Unknown command: {command}")
        
        elif trimmed_input and self.state["current_channel_id"]:
            # Send a message to the current channel
            if not self.state["is_connected"]:
                self.print_message("Not connected to server. Cannot send message.")
                return
            
            # Check if the channel is active before sending a message
            if self.state["channel_states"].get(self.state["current_channel_id"]) is False:
                self.print_message(f'Cannot send message: Channel {self.state["current_channel_id"]} is inactive.')
                self.display_prompt()
                return
            
            self.socket.emit("message", {
                "channelId": self.state["current_channel_id"],
                "content": trimmed_input
            })
            self.print_message(f"You sent: {trimmed_input}")
            
        elif trimmed_input:
            self.print_message("Error: Not in a channel. Join a channel first with /join [channel]")
        
        self.display_prompt()
        
    def extractJsonBlock(self, content):
        """Extract JSON block from content"""
        try:
            print('extracting STARTED:', content)
            regex = re.compile(r'\[json\](.*?)\[\/json\]', re.DOTALL)
            match = regex.search(content)
            jsonMatch = match.group(1) if match else None
            if jsonMatch:
                return json.loads(jsonMatch)
        except Exception as error:
            self.print_message(f"Error parsing JSON: {error}")
            return None
    
    def show_help(self):
        """Show help message"""
        self.print_message("Available commands:")
        self.print_message("/join [channel] - Join a channel (default: general)")
        self.print_message("/leave - Leave the current channel")
        self.print_message("/start [channel] - Start a channel (default: current or general)")
        self.print_message("/stop - Stop the current channel")
        self.print_message("/channel [channel] - Switch to or display current channel")
        self.print_message("/info - Get information about the current channel")
        self.print_message("/messages - Show recent messages in the current channel")
        self.print_message("/reconnect - Attempt to reconnect to the server")
        self.print_message("/exit - Exit the bot")
        self.print_message("/help - Show this help message")
        
        # Show custom help if available
        self.show_custom_help()
        
        self.print_message("To send a message, just type it and press enter")
    
    def print_message(self, message):
        """
        Print a message with timestamp
        
        Args:
            message (str): Message to print
        """
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        print(f'[{timestamp}] {message}')
    
    def display_prompt(self):
        """Display prompt to the user"""
        channel_status = f'({self.config["bot_id"]})[{self.state["current_channel_id"]}]' if self.state["current_channel_id"] else "[no channel]"
        
        channel_active = ""
        if self.state["current_channel_id"]:
            is_active = self.is_channel_active(self.state["current_channel_id"])
            channel_active = "active" if is_active else "inactive"
        
        connection_status = "connected" if self.state["is_connected"] else "disconnected"
        
        prompt = f'{channel_status}'
        if channel_active:
            prompt += f" ({channel_active})"
        prompt += f" ({connection_status}) > "
        
        # Print the prompt without newline and flush
        print(prompt, end="", flush=True)
    
    def should_respond_to(self, message):
        """
        Determine if the bot should respond to a message
        This method should be overridden by derived classes
        
        Args:
            message (dict): Message object
            
        Returns:
            bool: Whether the bot should respond
        """
        # Check if the channel is active before responding
        if self.state["channel_states"].get(message.get("channelId")) is False:
            return False
        
        # Base implementation: respond to messages that tag this bot
        tags = message.get("tags", [])
        return tags and self.config["bot_id"] in tags
    
    def handle_custom_command(self, command, args):
        """
        Handle custom commands
        This method should be overridden by derived classes
        
        Args:
            command (str): Command name
            args (list): Command arguments
            
        Returns:
            bool: Whether the command was handled
        """
        # Base implementation: no custom commands
        return False
    
    def show_custom_help(self):
        """
        Show custom help
        This method should be overridden by derived classes
        """
        # Base implementation: no custom help
        pass
    
    def is_channel_active(self, channel_id):
        """
        Check if a channel is active
        
        Args:
            channel_id (str): Channel ID to check
            
        Returns:
            bool: Whether the channel is active
        """
        # If we don't have state information, assume it's active
        if channel_id not in self.state["channel_states"]:
            return True
        return self.state["channel_states"][channel_id] is True
